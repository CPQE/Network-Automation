# utils.py or within main.py

def validate_and_format(raw_input):
    '''
    Ensures input is converted to a list of integers.
    Handles: Strings, empty input, and non-numeric types.
    '''
    # Requirement: Handle missing or invalid inputs
    if raw_input is None or raw_input == "":
        print("Warning: Input is empty. Using null-block default.")
        return [0]
    if isinstance(raw_input, str):
        # Handle alphanumeric/text by converting to bytes
        # This handles the "odd or even" requirement via padding
        data_bytes = raw_input.encode('utf-8')
        # Padding to even length for 16-bit (2-byte) blocks
        if len(data_bytes) % 2 != 0:
            data_bytes += b'\x00'
        # Convert byte pairs into a list of 16-bit integers
        blocks = []
        for i in range(0, len(data_bytes), 2):
            blocks.append((data_bytes[i] << 8) | data_bytes[i+1])
        return blocks
    if isinstance(raw_input, int):
        return [raw_input]
    # If it's something totally unexpected (like a list or dict)
    print(f"Error: Unsupported data type {type(raw_input)}. Returning empty block.")
    return [0]

def validate_key(key):
    '''Ensures the key fits in 8 bits (0-255)'''
    try:
        k = int(key)
        return k & 0xFF # Mask it to force it into 8 bits
    except (ValueError, TypeError):
        print("Invalid key format. Using default key 0xAA")
        return 0xAA
    
def blocks_to_string(blocks):
    """
    Converts a list of 16-bit integers back into a UTF-8 string.
    It splits each integer into two bytes and strips trailing null padding.
    """
    result_bytes = bytearray()
    for b in blocks:
        # Extract the high byte (left 8 bits)
        result_bytes.append((b >> 8) & 0xFF)
        # Extract the low byte (right 8 bits)
        result_bytes.append(b & 0xFF)

    # Decode to string and strip the \x00 padding we added in validate_and_format
    return result_bytes.decode('utf-8').rstrip('\x00')