import os

def read_raw_string(filename):
    if not os.path.exists(filename):
        return ""
    with open(filename, 'r') as f:
        return f.read().strip()

def write_raw_string(filename, data):
    with open(filename, 'w') as f:
        f.write(data)

def write_encrypted_blocks(filename, blocks):
    with open(filename, 'w') as f:
        # Saving as comma-separated integers to avoid encoding issues
        f.write(",".join(map(str, blocks)))

def read_encrypted_blocks(filename):
    if not os.path.exists(filename):
        return []
    with open(filename, 'r') as f:
        content = f.read().strip()
        return [int(b) for b in content.split(",")] if content else []